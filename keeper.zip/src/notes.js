const notes = [
  {
    key: 1,
    title: "Delegration",
    content: "Q. How many programmers does it take to charge a light bulb?"
  },
  {
    key: 2,
    title: "Loops",
    content: "Q. How many programmers does shower in forever?"
  },
  {
    key: 3,
    title: "Hello",
    content: "Q. How many programmers does shower in forever?"
  },
  {
    key: 4,
    title: "Loops",
    content: "Q. How many programmers does shower in forever?"
  },
  {
    key: 5,
    title: "Loops",
    content: "Q. How many programmers does shower in forever?"
  },
  {
    key: 6,
    title: "Jquery",
    content: "Practice Mode"
  }
];

export default notes;
