import react from "react";

function Footer() {
  return (
    <footer>
      <p>Copyright @ 2019</p>
    </footer>
  );
}
export default Footer;
